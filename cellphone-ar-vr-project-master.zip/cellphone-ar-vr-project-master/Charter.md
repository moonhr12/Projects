# Charter 
<b>Project Name: </b> Cellphone as the input device in the virtual world

<b>Project Manager: </b> Dr. Xianglong Feng.

<b>Last Revision Date: </b> Sept 30 2022

<b>Project purpose statement: </b> 

Cellphone is very common in our daily life. It contains not only powerful computing hardwares but also multiple sensors. We could use this platform to perform many tasks based on all the resources in it. In this project, we aim to leverage the cellphone to work as an input device for the 3D world for AR/VR or PC. Currently, the human computer interaction in the 3D world (PC or VR) requires devices such as keyboard/mouse or controllers. However, the mouse could only move along two directions (2 degrees of freedoms) and the controllers are not the standard devices for the VR headset. 

<b>Project objectives: </b> 

We plan to leverage the cell phone to help people edit the 3D world. The tasks for this project are listed below:
<ul>
<li> Design a virtual world for AR/VR or PC. Design a standard interface for editing.</li>
<li> Collect the position data from the sensors in the phone. Calculate the movement of the cellphone to identify the actions by the cellphone.</li>
<li> Design special applications based on the above software. Applications could be drawing a 3D object, "smart pen" for writing in AR/VR.</li>
</ul>

<br>

<h2>Project Scope</h2>

<b>Deliverables: </b> <br>
<ul>
<li>Smartphone app for collecting sensor data</li>
<li>Server for receiving and processing data</li>
<li>Unity App for VR space running on Oculus</li>
</ul>



<b>Creative Requirements</b> <br>

<b>Out of Scope</b>


<h2>Resources</h2>
<ul>
<li>Oculus VR Headset</li>
<li>One Plus 8 Pro Smartphone</li>
<li> Unity Version 2021.3.11f1 </li>
</ul>

<h2>Stakeholders and approvers</h2>

<ul>
<li>Dr Lynn Stahr</li>
<li>Dr Xianglong Feng</li>
</ul>
