# Team Working Agreement

### Team Roles
* Team Leader: Tae Won
* Product Owner: Kyosung Hwang
* Scrum Master: Sean Moon
* Development Team: Sean Moon, Tae Won, Kyosung Hwang, Patrick Oh


### Team Values
We Value:
* commitment to consistent tracking 
* positive mindset
* quality code 
* maintaining good documentation
* good communication
* effective use of time
* respecting boundaries
* good planning
* consistency
* accountability & responsibility
* being open-minded
* experimentation


### Team Habits
* Changes made to the sprint backlog needs to be approved by the product manager
* Update the sprint backlog after each client & team meetings
* Document any issues that come up during any phase of development
* Document significant changes
* Adhere to the Definition of Done
* Respect other Team members
* Be one time for meetings

### Definition of Done

**Definition of Done for a FEATURE**
* Code is reviewed by one other peer
* Code compiles without errors
* Project build without errors
* Acceptace criteria is met
* Documentation is updated

**Definition of Done for a SPRINT**
* Issue board updated
* Project builds without errors
* Project is deployed on test devices/environments

### Code Management
We will manage our code using the GitLab version control system. Using this system we intend on creating well-documented and labeled branches for specific tasks NOT for specific individuals. Using this method our code will be clean, well-documented, and separated until merging it together.

### Agile Methodology
Using Agile and Scrum methodology our team plans to have a Sprint Planning session at the beginning of every sprint. We will meet and converse daily through Discord, and hold a longer sprint review and sprint retrospective at the end of each sprint.



