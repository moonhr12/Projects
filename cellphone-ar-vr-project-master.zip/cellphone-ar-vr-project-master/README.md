# Cellphone & AR/VR

Cellphone is a very common tool in our daily life. It contains multiple sensors that help us navigate in the real world. In this project, we aim to leverage the cellphone and its sensors to work as an input device for the 3D world or for the AR & VR space. Traditional methods of human-computer interaction in the 3D world, whether its in PC or in VR, require devices such as keyboard, mouse or controllers.

# Project Description

### Team Members & Roles
* Team Leader : Tae Won
* Product Owner : Kyosung Hwang
* Scrum Master : Sean Moon
* Development Team
  * Mobile " Tae Won, Kyosung Hwang
  * VR : Patrick Oh, Sean Moon

### Scope
System Objective : Use a smartphone as a controller for interaction in a VR space

Hardware : Oculus Quest 2 VR Headset, One Plus 8 Smartphone

Major Software Functions :
1. Smartphone App : collect the sensor data, apply sensor fusion and send data to the VR app
2. VR World : provide a virtual space and a few simple objects such as a ping pong table and a whiteboard that the user can interact with through their smartphone app

Major Design Contraints and Limitations
1. The sensors on the smartphone only provides 3 degrees of freedom (rotational motion along the x, y, z axis), while an ideal controller for the VR world should provide 6 degrees of freedom (rotational and translational motion along the x, y, z axis).

### Tasks
The following items are the goals for this project

* Design a virtual world for AR/VR or PC. Design a standard interface for editing.
* Collect the position data from the sensors in the phone. Calculate the movement of the cellphone to identify the actions by the cellphone.
* Design special applications based on the above software. Applications could be drawing a 3D object, "smart pen" for writing in AR/VR



# Branches

This project templates includes 3 branches to start with.  

| **Name**   | **Description** |
| ------ | ------ |
| Master         | Protected branch.  You cannot push directly to master.  This branch is what we push to the test server (ceclnx for example) or other devices for our client to review. |
| smarphoneController| Working branch for the smartphone app. This branch contains the files for the smartphone app that allows our smartphone to function as a controller.|
| VRUnityPrototype| Working branch for the VR app. This branch contains the files for the VR space that we plan to implement on the Oculus Quest 2. |


# Getting Started

### Prerequisites
The following prgrams are required for this project

* Unity
* Mobile Application
### Installation
Unity Installation

1. Go to the [website](https://unity3d.com/get-unity/download/archive) and find the version 2021.3.11f1.
2. Click either "Downloads (Win)" or "Downloads (Mac)".
3. Click "Unity Installer" to install Unity.
4. You will be asked "Select components to install," then check "Android Build Support" and hit next.

Mobile Application Installation

### Run Application
Unity
1. Download [Unity project] and open with this project.
2. Click the play button at the mid-top.

Mobile

# Project Design
Sequence Diagram

![sequenceDiagram.png](./sequenceDiagram.png)


# Technical Specification

[1857.9-2021 - IEEE Standard for Immersive Visual Content Coding](https://ieeexplore-ieee-org.proxy.lib.miamioh.edu/document/9726138/definitions#definitions) <br>

* This technical standard defines standards for efficient and manageable coding for immersive visual content. For the purposes of our project we are specifically emphasizing on the standards made for VR systems. This standard includes strict definitions for how 3d spaces are represented, protocols for system designs, consistent naming conventions for VR design patterns, and many more useful design patterns for geometries in a 3d space. This standard allows for consistency with coordinate systems, math, naming conventions, and includes many useful design patterns for working in 3d VR environments.

[24748-5-2017 - ISO/IEC/IEEE International Standard - Systems and Software Engineering – Life Cycle Management –Part 5 : Software Development Planning](https://ieeexplore-ieee-org.proxy.lib.miamioh.edu/document/7955095)

* This technical standard provides guidance on the life cycle management of software and systems. It covers the processes of developing a successful plan for software development based on the project's contract, applicable organizational and technical management processes, and the software development project team. This standard also covers the management process after the development lifecycle - when the software becomes obsolete and retires. This standard allows for the effective communication and cooperation among various teams that build the software.


# Project Charter
*Please look at the file TeamWorkingAgreement.md or click on the link below.*

[Project Charter](https://gitlab.csi.miamioh.edu/2023-capstone/cellphone-ar_vr-group/cellphone-ar-vr-project/-/blob/master/Charter.md)


# Team Working Agreement
*Please look at the file TeamWorkingAgreement.md or click on the link below.*

[Team Working Agreement](https://gitlab.csi.miamioh.edu/2023-capstone/cellphone-ar_vr-group/cellphone-ar-vr-project/-/blob/master/TeamWorkingAgreement.md)







