## Purpose:
[describe the purpose of this work here]

### Estimtes and reminders:
/estimate 32h 

** Check out [Gitlab Quick Actions](https://docs.gitlab.com/ee/user/project/quick_actions.html) to improve your use of Gitlab

## Acceptance Criteria:

- [ ] Should ‹testable condition that should be satisfied›
- [ ] Should ‹testable condition that should be satisfied›
- [ ] …


### Tasks
- [ ] start defining some preliminary tasks...
- [ ] during sprint planning...
- [ ] follow your team's 'definition of done'
